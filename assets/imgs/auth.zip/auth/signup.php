<?php
    include_once 'resource/database.php';

    if (isset($_POST['email'])) {
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sqlInsert = "INSERT INTO users (`username`,`password`,`email`,`join_date`)
                      VALUES (:username, :email, :passowrd, now());";

        $statement = $db->prepare($sqlInsert);

        try {
            $statement->execute(array(
                ':username'=>$username,
                ':password'=>$password,
                ':email'=>$email
            ));

            if ($statement->rowCount() == 1) {
                $result = "Registration Successful";
            }
        }
        catch (PDOException $ex) {
            $result = "An error occurred : ".$ex->getMessage();
        }
    }
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
</head>
<body>

<h3>Register Form</h3>

<?php
    if (isset($result)) {echo $result;}
?>

<form action="">
    <table>
        <tr>
            <td>Email:</td><td><input type="email" value=""  name="email"></td>
        </tr>
        <tr>
            <td>Username:</td><td><input type="text" value="" name="username"></td>
        </tr>
        <tr>
            <td>Password:</td><td><input type="password" value="" name="password"></td>
        </tr>
        <tr>
            <td><input type="submit" value="Signup"  name="signup"></td>
        </tr>
    </table>
</form>



<p>You are loggedin as {username} <a href="logout.php">Logout</a></p>
<p><a href="index.php">Back</a></p>

</body>
</html>