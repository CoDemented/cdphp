<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>

<p>Your are currently not signed in <a href="login.php">Login</a> Not yet a member? <a href="signup.php"> Signup</a></p>

<p>You are loggedin as {username} <a href="logout.php">Logout</a></p>


</body>
</html>